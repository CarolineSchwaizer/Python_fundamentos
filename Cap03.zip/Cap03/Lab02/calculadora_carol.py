#Calculadora em Python

print("************** Pyhton Calculator ******************")

print('Selecione o número da opção desejada:')
print("1 - Soma")
print('2 - Subtração')
print('3 - Multiplicação')
print('4 - Divisão')

operacao_mat = int(input("Digite sua opção (1/2/3/4): "))
if operacao_mat <= 4:
	num1 = int(input("Digite o primeiro número: "))
	num2 = int(input("Digite o segundo número: "))
	if operacao_mat == 1:
		soma = num1 + num2
		print(num1, "+", num2, "=", soma)
	elif operacao_mat == 2:
		subt = num1 - num2
		print(num1, "-", num2, "=", subt)
	elif operacao_mat == 3:
		mult = num1 * num2
		print(num1, "*", num2, "=", mult)
	else:
		div = num1 / num2
		print(num1, "/", num2, "=", div)
else:
	print('Opção inválida!')