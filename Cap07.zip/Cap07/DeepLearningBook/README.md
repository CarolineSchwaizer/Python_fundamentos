# Deep Learning Book

Acesse o livro online gratuito da DSA sobre Deep Learning em:

http://www.deeplearningbook.com.br





